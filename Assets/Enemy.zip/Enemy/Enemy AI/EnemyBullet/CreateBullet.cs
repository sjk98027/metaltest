﻿using UnityEngine;
using System.Collections;

public class CreateBullet : MonoBehaviour {

	public float moveSpeed;
	public int damage = 1;
	public SpriteRenderer sR;

//	public bool HaveLife
//	{
//		get { return haveLife;}
//	}

	public float MoveSpeed{
		get { return moveSpeed;}
	}

	public int Damage{
		get { return damage;}
	}




}
